
package com.ltztec.entities;

import java.awt.image.BufferedImage;

public class HeartLife extends Entity{

	public HeartLife(int x, int y, int width, int height, BufferedImage sprite) {
		super(x, y, width, height, sprite);
	
	}

}
