package com.ltztec.entities;

import java.awt.image.BufferedImage;




public class House extends Entity{
	
	
	public House(int x, int y, int width, int height, BufferedImage sprite) {
		super(x, y, width, height, sprite);
		
	} 
	

}
