package com.ltztec.world;

import java.awt.image.BufferedImage;

public class FloorTile extends Tile{

	public FloorTile(int x, int y,  BufferedImage sprite) {
		super(x, y, sprite);
		
	}

}
