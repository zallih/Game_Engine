package com.ltztec.world;

import java.awt.image.BufferedImage;

public class FlowerTile extends Tile{

	public FlowerTile(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);
	}


}
